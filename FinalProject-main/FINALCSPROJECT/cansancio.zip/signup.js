function saveAndRedirect() {

  document.querySelectorAll(".error").forEach(e => e.textContent = "");

  const first = document.getElementById("firstName").value.trim();
  const last = document.getElementById("lastName").value.trim();
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value.trim();
  const contact = document.getElementById("contact").value.trim();
  const reason = document.getElementById("reason").value.trim();
  const sex = document.querySelector("input[name='sex']:checked");

  let valid = true;

  if (!first) {
    document.getElementById("errorFirst").textContent = "Required";
    valid = false;
  }
  if (!last) {
    document.getElementById("errorLast").textContent = "Required";
    valid = false;
  }
  if (!sex) {
    document.getElementById("errorSex").textContent = "Required";
    valid = false;
  }
  if (!email) {
    document.getElementById("errorEmail").textContent = "Required";
    valid = false;
  }
  if (!password) {
    document.getElementById("errorPassword").textContent = "Required";
    valid = false;
  }
  if (!reason) {
    document.getElementById("errorReason").textContent = "Required";
    valid = false;
  }

  if (!valid) return false;

  
  localStorage.setItem("firstName", first);
  localStorage.setItem("lastName", last);
  localStorage.setItem("email", email);
  localStorage.setItem("contact", contact);
  localStorage.setItem("sex", sex.value);
  localStorage.setItem("reason", reason);

 
  window.location.href = "proj_profile_cansancio.html";
  return false; 
}